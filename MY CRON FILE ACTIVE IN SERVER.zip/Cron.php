<?php 

$dbhost = "127.0.0.1";
$dbname = "infofl7n_flej";
$dbuser = "infofl7n_flej";
$dbpass = "aslan@5555";

$conn = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "SELECT * FROM `vacancies` WHERE SortOrder=1 AND PremiumEndDate IS NOT NULL";
$stmt = $conn->prepare($sql);
$stmt->execute();

$vacancies = $stmt->fetchAll();

foreach ($vacancies as $vacancy) {
    if ($vacancy['PremiumEndDate'] <= date("Y-m-d H:i:s")) {
        $sql = "UPDATE `vacancies` SET SortOrder=0, PremiumEndDate=NULL WHERE id=:id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $vacancy['id']);
        $stmt->execute();
    }
}

$sql = "SELECT * FROM `company_users` WHERE PremiumEndDate IS NOT NULL";
$stmt = $conn->prepare($sql);
$stmt->execute();

$companies = $stmt->fetchAll();

foreach ($companies as $comp) {
    if ($comp['PremiumEndDate'] <= date("Y-m-d H:i:s")) {
        $sql = "UPDATE `company_users` SET PremiumEndDate=NULL WHERE id=:id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $comp['id']);
        $stmt->execute();
    }
}

$sql = "SELECT * FROM `users` WHERE PremiumEndDate IS NOT NULL";
$stmt = $conn->prepare($sql);
$stmt->execute();

$users = $stmt->fetchAll();

foreach ($users as $user) {
    if ($user['PremiumEndDate'] <= date("Y-m-d H:i:s")) {
        $sql = "UPDATE `users` SET PremiumEndDate=NULL WHERE id=:id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id', $user['id']);
        $stmt->execute();
    }
}


$date = date("Y-m-d");
$sql = "SELECT * FROM `vacancies` WHERE EndDate <= :date";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':date', $date);
$stmt->execute();

$vacancies = $stmt->fetchAll();

foreach ($vacancies as $vacancy) {
    $sql = "UPDATE `vacancies` SET Status=0 WHERE id=:id";
    $stmt = $conn->prepare($sql);   
    $stmt->bindParam(':id', $vacancy['id']);
    $stmt->execute();
}